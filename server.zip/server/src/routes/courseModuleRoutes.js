const express = require('express');
const router = express.Router();
const db = require('../db');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const logger = require('../logger');
const { lecturerAuthMiddleware } = require('./lecturerAuthRoutes');
const { studentAuthMiddleware } = require('./studentAuthRoutes');

// Setup upload directories
const materialsDir = path.join(__dirname, '../../uploads/materials');
const assignmentsDir = path.join(__dirname, '../../uploads/assignments');
const submissionsDir = path.join(__dirname, '../../uploads/submissions');

[materialsDir, assignmentsDir, submissionsDir].forEach(dir => {
  fs.mkdirSync(dir, { recursive: true });
});

// Multer configuration for materials
const materialsStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    const moduleId = req.params.moduleId || req.body.moduleId;
    const folder = path.join(materialsDir, `module_${moduleId}`);
    fs.mkdirSync(folder, { recursive: true });
    cb(null, folder);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const name = `${Date.now()}-${file.originalname}`;
    cb(null, name);
  }
});

const uploadMaterial = multer({ 
  storage: materialsStorage,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB limit
  fileFilter: (req, file, cb) => {
    const allowedTypes = /pdf|doc|docx|ppt|pptx|xls|xlsx|zip|mp4|avi|mov|jpg|jpeg|png/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only documents, videos, and images are allowed.'));
    }
  }
});

// Multer configuration for assignment submissions
const submissionStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    const assignmentId = req.params.assignmentId;
    const studentId = req.student.studentId;
    const folder = path.join(submissionsDir, `assignment_${assignmentId}`, `student_${studentId}`);
    fs.mkdirSync(folder, { recursive: true });
    cb(null, folder);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const name = `${Date.now()}-${file.originalname}`;
    cb(null, name);
  }
});

const uploadSubmission = multer({ 
  storage: submissionStorage,
  limits: { fileSize: 25 * 1024 * 1024 } // 25MB limit
});

/**
 * Get all modules for a course (accessible by both students and lecturers)
 * GET /api/course-modules/course/:courseId
 */
router.get('/course/:courseId', async (req, res) => {
  try {
    const { courseId } = req.params;
    const { batchId } = req.query;
    
    let query = `
      SELECT cm.*, lu.id as created_by_id, l.full_name as created_by_name,
             (SELECT COUNT(*) FROM course_materials WHERE module_id = cm.id) as materials_count,
             (SELECT COUNT(*) FROM course_assignments WHERE module_id = cm.id) as assignments_count
      FROM course_modules cm
      JOIN lecturer_users lu ON cm.created_by = lu.id
      JOIN lecturers l ON lu.lecturer_id = l.id
      WHERE cm.course_id = ? AND cm.status = 'Published'
    `;
    
    const params = [courseId];
    
    if (batchId) {
      query += ' AND (cm.batch_id IS NULL OR cm.batch_id = ?)';
      params.push(batchId);
    }
    
    query += ' ORDER BY cm.sequence_order ASC';
    
    const modules = await db.queryPromise(query, params);
    
    res.json(modules);
  } catch (error) {
    logger.error('Error fetching course modules:', error);
    res.status(500).json({ error: 'Failed to fetch modules' });
  }
});

/**
 * Create a new module (lecturer only)
 * POST /api/course-modules
 */
router.post('/', lecturerAuthMiddleware, async (req, res) => {
  try {
    const {
      course_id,
      batch_id,
      module_name,
      module_code,
      description,
      sequence_order,
      duration_hours,
      is_mandatory = true
    } = req.body;
    
    if (!course_id || !module_name) {
      return res.status(400).json({ error: 'Course ID and module name are required' });
    }
    
    const insertQuery = `
      INSERT INTO course_modules 
      (course_id, batch_id, module_name, module_code, description, 
       sequence_order, duration_hours, is_mandatory, created_by, status)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Published')
    `;
    
    const result = await db.queryPromise(insertQuery, [
      course_id,
      batch_id || null,
      module_name,
      module_code,
      description,
      sequence_order || 0,
      duration_hours || 0,
      is_mandatory,
      req.lecturer.lecturerUserId
    ]);
    
    res.status(201).json({
      success: true,
      moduleId: result.insertId,
      message: 'Module created successfully'
    });
    
  } catch (error) {
    logger.error('Error creating module:', error);
    res.status(500).json({ error: 'Failed to create module' });
  }
});

module.exports = router;

