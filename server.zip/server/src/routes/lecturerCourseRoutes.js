const express = require('express');
const router = express.Router();
const db = require('../db');
const multer = require('multer');
const path = require('path');
const fs = require('fs').promises;
const logger = require('../logger');
const { lecturerAuthMiddleware } = require('./lecturerAuthRoutes');

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: async (req, file, cb) => {
    const uploadPath = path.join(__dirname, '../../uploads/course-materials');
    try {
      await fs.mkdir(uploadPath, { recursive: true });
      cb(null, uploadPath);
    } catch (error) {
      cb(error);
    }
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB limit
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|gif|pdf|doc|docx|ppt|pptx|xls|xlsx|zip|mp4|avi|mov/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Invalid file type'));
    }
  }
});

/**
 * Get lecturer's courses and batches
 */
router.get('/my-courses', lecturerAuthMiddleware, async (req, res) => {
  try {
    const lecturerUserId = req.lecturer.id; // This comes from lecturer_users table
    
    // First get the lecturer_id from lecturers table
    const lecturerQuery = `
      SELECT l.id as lecturer_id 
      FROM lecturers l 
      JOIN lecturer_users lu ON l.id = lu.lecturer_id 
      WHERE lu.id = ?
    `;
    
    const lecturerResult = await db.queryPromise(lecturerQuery, [lecturerUserId]);
    
    if (lecturerResult.length === 0) {
      return res.status(404).json({ error: 'Lecturer not found' });
    }
    
    const lecturerId = lecturerResult[0].lecturer_id;
    
    // Get courses with proper column names from your database
    const coursesQuery = `
      SELECT DISTINCT c.id, c.courseName, c.courseId, 
             c.description, c.fees, c.duration, c.status,
             lc.primary_course, lc.module as assigned_module
      FROM courses c
      JOIN lecturer_courses lc ON c.id = lc.course_id
      WHERE lc.lecturer_id = ? AND lc.status = 'Active'
    `;
    
    const courses = await db.queryPromise(coursesQuery, [lecturerId]);
    
    // Get batches for each course
    for (let course of courses) {
      const batchesQuery = `
        SELECT b.id, b.batch_name, b.start_date, b.end_date, b.status,
               b.capacity as max_students,
               c.courseName,
               (SELECT COUNT(*) FROM student_batches sb WHERE sb.batch_id = b.id AND sb.status = 'Active') as student_count
        FROM batches b
        JOIN courses c ON b.course_id = c.id
        JOIN lecturer_batches lb ON b.id = lb.batch_id
        WHERE lb.lecturer_id = ? AND b.course_id = ? AND lb.status IN ('Assigned', 'Active')
      `;
      
      course.batches = await db.queryPromise(batchesQuery, [lecturerId, course.id]);
    }
    
    res.json(courses);
  } catch (error) {
    logger.error('Error fetching lecturer courses:', error);
    res.status(500).json({ error: 'Failed to fetch courses' });
  }
});

/**
 * Get modules for a course
 */
router.get('/courses/:courseId/modules', lecturerAuthMiddleware, async (req, res) => {
  try {
    const { courseId } = req.params;
    
    const query = `
      SELECT m.*, 
             (SELECT COUNT(*) FROM course_materials WHERE module_id = m.id) as material_count,
             (SELECT COUNT(*) FROM course_assignments WHERE module_id = m.id) as assignment_count
      FROM course_modules m
      WHERE m.course_id = ?
      ORDER BY m.sequence_order, m.created_at
    `;
    
    const modules = await db.queryPromise(query, [courseId]);
    res.json(modules);
  } catch (error) {
    logger.error('Error fetching modules:', error);
    res.status(500).json({ error: 'Failed to fetch modules' });
  }
});

/**
 * Create a new module
 */
router.post('/courses/:courseId/modules', lecturerAuthMiddleware, async (req, res) => {
  try {
    const { courseId } = req.params;
    const { title, description, sequence_order } = req.body;
    const lecturerUserId = req.lecturer.id;
    
    // First get the lecturer_id from lecturers table
    const lecturerQuery = `
      SELECT l.id as lecturer_id 
      FROM lecturers l 
      JOIN lecturer_users lu ON l.id = lu.lecturer_id 
      WHERE lu.id = ?
    `;
    
    const lecturerResult = await db.queryPromise(lecturerQuery, [lecturerUserId]);
    
    if (lecturerResult.length === 0) {
      return res.status(404).json({ error: 'Lecturer not found' });
    }
    
    const lecturerId = lecturerResult[0].lecturer_id;
    
    // Verify lecturer has access to this course
    const accessCheck = await db.queryPromise(
      'SELECT * FROM lecturer_courses WHERE lecturer_id = ? AND course_id = ? AND status = "Active"',
      [lecturerId, courseId]
    );
    
    if (accessCheck.length === 0) {
      return res.status(403).json({ error: 'Access denied to this course' });
    }
    
    const result = await db.queryPromise(
      'INSERT INTO course_modules (course_id, module_name, description, sequence_order, created_by) VALUES (?, ?, ?, ?, ?)',
      [courseId, title, description, sequence_order || 0, lecturerUserId]
    );
    
    res.json({ 
      success: true, 
      moduleId: result.insertId,
      message: 'Module created successfully' 
    });
  } catch (error) {
    logger.error('Error creating module:', error);
    res.status(500).json({ error: 'Failed to create module' });
  }
});

/**
 * Update a module
 */
router.put('/modules/:moduleId', lecturerAuthMiddleware, async (req, res) => {
  try {
    const { moduleId } = req.params;
    const { title, description, sequence_order, status } = req.body;
    
    await db.queryPromise(
      'UPDATE course_modules SET module_name = ?, description = ?, sequence_order = ?, status = ? WHERE id = ?',
      [title, description, sequence_order, status, moduleId]
    );
    
    res.json({ success: true, message: 'Module updated successfully' });
  } catch (error) {
    logger.error('Error updating module:', error);
    res.status(500).json({ error: 'Failed to update module' });
  }
});

/**
 * Delete a module
 */
router.delete('/modules/:moduleId', lecturerAuthMiddleware, async (req, res) => {
  try {
    const { moduleId } = req.params;
    
    // Check if module has content
    const materials = await db.queryPromise(
      'SELECT COUNT(*) as count FROM course_materials WHERE module_id = ?',
      [moduleId]
    );
    
    const assignments = await db.queryPromise(
      'SELECT COUNT(*) as count FROM course_assignments WHERE module_id = ?',
      [moduleId]
    );
    
    if (materials[0].count > 0 || assignments[0].count > 0) {
      return res.status(400).json({ 
        error: 'Cannot delete module with existing content. Please remove all materials and assignments first.' 
      });
    }
    
    await db.queryPromise('DELETE FROM course_modules WHERE id = ?', [moduleId]);
    res.json({ success: true, message: 'Module deleted successfully' });
  } catch (error) {
    logger.error('Error deleting module:', error);
    res.status(500).json({ error: 'Failed to delete module' });
  }
});

/**
 * Get materials for a module in a specific batch
 */
router.get('/modules/:moduleId/materials', lecturerAuthMiddleware, async (req, res) => {
  try {
    const { moduleId } = req.params;
    const { batchId } = req.query;
    
    let query = 'SELECT * FROM course_materials WHERE module_id = ?';
    let params = [moduleId];
    
    if (batchId) {
      query += ' AND batch_id = ?';
      params.push(batchId);
    }
    
    query += ' ORDER BY created_at DESC';
    
    const materials = await db.queryPromise(query, params);
    
    res.json(materials);
  } catch (error) {
    logger.error('Error fetching materials:', error);
    res.status(500).json({ error: 'Failed to fetch materials' });
  }
});

/**
 * Get batch details with modules, materials, and assignments
 */
router.get('/batches/:batchId/content', lecturerAuthMiddleware, async (req, res) => {
  try {
    const { batchId } = req.params;
    const lecturerUserId = req.lecturer.id;
    
    // First get the lecturer_id from lecturers table
    const lecturerQuery = `
      SELECT l.id as lecturer_id 
      FROM lecturers l 
      JOIN lecturer_users lu ON l.id = lu.lecturer_id 
      WHERE lu.id = ?
    `;
    
    const lecturerResult = await db.queryPromise(lecturerQuery, [lecturerUserId]);
    
    if (lecturerResult.length === 0) {
      return res.status(404).json({ error: 'Lecturer not found' });
    }
    
    const lecturerId = lecturerResult[0].lecturer_id;
    
    // Verify lecturer has access to this batch
    const batchAccess = await db.queryPromise(
      `SELECT b.*, c.courseName, c.courseId
       FROM batches b 
       JOIN courses c ON b.course_id = c.id
       JOIN lecturer_batches lb ON b.id = lb.batch_id
       WHERE b.id = ? AND lb.lecturer_id = ? AND lb.status IN ('Assigned', 'Active')`,
      [batchId, lecturerId]
    );
    
    if (batchAccess.length === 0) {
      return res.status(403).json({ error: 'Access denied to this batch' });
    }
    
    const batch = batchAccess[0];
    
    // Get modules for this course
    const modules = await db.queryPromise(
      `SELECT m.*, 
              (SELECT COUNT(*) FROM course_materials WHERE module_id = m.id AND batch_id = ?) as material_count,
              (SELECT COUNT(*) FROM course_assignments WHERE module_id = m.id AND batch_id = ?) as assignment_count
       FROM course_modules m
       WHERE m.course_id = ?
       ORDER BY m.sequence_order, m.created_at`,
      [batchId, batchId, batch.course_id]
    );
    
    // Get materials and assignments for each module
    for (let module of modules) {
      // Get materials
      module.materials = await db.queryPromise(
        'SELECT * FROM course_materials WHERE module_id = ? AND batch_id = ? ORDER BY created_at DESC',
        [module.id, batchId]
      );
      
      // Get assignments
      module.assignments = await db.queryPromise(
        'SELECT * FROM course_assignments WHERE module_id = ? AND batch_id = ? ORDER BY created_at DESC',
        [module.id, batchId]
      );
    }
    
    batch.modules = modules;
    
    res.json(batch);
  } catch (error) {
    logger.error('Error fetching batch content:', error);
    res.status(500).json({ error: 'Failed to fetch batch content' });
  }
});

/**
 * Upload course material
 */
router.post('/modules/:moduleId/materials', lecturerAuthMiddleware, upload.single('file'), async (req, res) => {
  try {
    const { moduleId } = req.params;
    const { title, description, type, batchId } = req.body;
    const lecturerUserId = req.lecturer.id;
    
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }
    
    if (!batchId) {
      return res.status(400).json({ error: 'Batch ID is required' });
    }
    
    const result = await db.queryPromise(
      `INSERT INTO course_materials 
       (module_id, batch_id, title, description, material_type, file_path, file_name, file_size, uploaded_by) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [moduleId, batchId, title, description, type, req.file.path, req.file.originalname, 
       req.file.size, lecturerUserId]
    );
    
    res.json({ 
      success: true, 
      materialId: result.insertId,
      message: 'Material uploaded successfully' 
    });
  } catch (error) {
    logger.error('Error uploading material:', error);
    res.status(500).json({ error: 'Failed to upload material' });
  }
});

/**
 * Delete course material
 */
router.delete('/materials/:materialId', lecturerAuthMiddleware, async (req, res) => {
  try {
    const { materialId } = req.params;
    
    // Get file path before deleting
    const material = await db.queryPromise(
      'SELECT file_path FROM course_materials WHERE id = ?',
      [materialId]
    );
    
    if (material.length > 0 && material[0].file_path) {
      // Delete file from filesystem
      try {
        await fs.unlink(material[0].file_path);
      } catch (err) {
        logger.error('Error deleting file:', err);
      }
    }
    
    await db.queryPromise('DELETE FROM course_materials WHERE id = ?', [materialId]);
    res.json({ success: true, message: 'Material deleted successfully' });
  } catch (error) {
    logger.error('Error deleting material:', error);
    res.status(500).json({ error: 'Failed to delete material' });
  }
});

/**
 * Get assignments for a module
 */
router.get('/modules/:moduleId/assignments', lecturerAuthMiddleware, async (req, res) => {
  try {
    const { moduleId } = req.params;
    
    const assignments = await db.queryPromise(
      `SELECT a.*, 
              (SELECT COUNT(*) FROM assignment_submissions WHERE assignment_id = a.id) as submission_count,
              (SELECT COUNT(*) FROM assignment_submissions WHERE assignment_id = a.id AND status = 'graded') as graded_count
       FROM course_assignments a 
       WHERE a.module_id = ? 
       ORDER BY a.due_date ASC`,
      [moduleId]
    );
    
    res.json(assignments);
  } catch (error) {
    logger.error('Error fetching assignments:', error);
    res.status(500).json({ error: 'Failed to fetch assignments' });
  }
});

/**
 * Create an assignment
 */
router.post('/modules/:moduleId/assignments', lecturerAuthMiddleware, async (req, res) => {
  try {
    const { moduleId } = req.params;
    const { title, description, type, points, due_date, instructions, allow_late_submission } = req.body;
    const lecturerId = req.lecturer.lecturerId;
    
    const result = await db.queryPromise(
      `INSERT INTO course_assignments 
       (module_id, title, description, type, points, due_date, instructions, 
        allow_late_submission, created_by) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [moduleId, title, description, type, points, due_date, instructions, 
       allow_late_submission || false, lecturerId]
    );
    
    res.json({ 
      success: true, 
      assignmentId: result.insertId,
      message: 'Assignment created successfully' 
    });
  } catch (error) {
    logger.error('Error creating assignment:', error);
    res.status(500).json({ error: 'Failed to create assignment' });
  }
});

/**
 * Update an assignment
 */
router.put('/assignments/:assignmentId', lecturerAuthMiddleware, async (req, res) => {
  try {
    const { assignmentId } = req.params;
    const { title, description, type, points, due_date, instructions, allow_late_submission, is_published } = req.body;
    
    await db.queryPromise(
      `UPDATE course_assignments 
       SET title = ?, description = ?, type = ?, points = ?, due_date = ?, 
           instructions = ?, allow_late_submission = ?, is_published = ?
       WHERE id = ?`,
      [title, description, type, points, due_date, instructions, 
       allow_late_submission, is_published, assignmentId]
    );
    
    res.json({ success: true, message: 'Assignment updated successfully' });
  } catch (error) {
    logger.error('Error updating assignment:', error);
    res.status(500).json({ error: 'Failed to update assignment' });
  }
});

/**
 * Get assignment submissions
 */
router.get('/assignments/:assignmentId/submissions', lecturerAuthMiddleware, async (req, res) => {
  try {
    const { assignmentId } = req.params;
    
    const submissions = await db.queryPromise(
      `SELECT s.*, st.full_name as student_name, st.id_number
       FROM assignment_submissions s
       JOIN students st ON s.student_id = st.id
       WHERE s.assignment_id = ?
       ORDER BY s.submitted_at DESC`,
      [assignmentId]
    );
    
    res.json(submissions);
  } catch (error) {
    logger.error('Error fetching submissions:', error);
    res.status(500).json({ error: 'Failed to fetch submissions' });
  }
});

/**
 * Grade a submission
 */
router.put('/submissions/:submissionId/grade', lecturerAuthMiddleware, async (req, res) => {
  try {
    const { submissionId } = req.params;
    const { grade, feedback } = req.body;
    const lecturerId = req.lecturer.lecturerId;
    
    await db.queryPromise(
      `UPDATE assignment_submissions 
       SET grade = ?, feedback = ?, status = 'graded', graded_by = ?, graded_at = NOW()
       WHERE id = ?`,
      [grade, feedback, lecturerId, submissionId]
    );
    
    res.json({ success: true, message: 'Submission graded successfully' });
  } catch (error) {
    logger.error('Error grading submission:', error);
    res.status(500).json({ error: 'Failed to grade submission' });
  }
});

/**
 * Create an announcement
 */
router.post('/courses/:courseId/announcements', lecturerAuthMiddleware, async (req, res) => {
  try {
    const { courseId } = req.params;
    const { title, content, priority, target_batches } = req.body;
    const lecturerId = req.lecturer.lecturerId;
    
    const result = await db.queryPromise(
      `INSERT INTO announcements 
       (course_id, title, content, priority, target_batches, created_by, type) 
       VALUES (?, ?, ?, ?, ?, ?, 'course')`,
      [courseId, title, content, priority || 'normal', 
       JSON.stringify(target_batches || []), lecturerId]
    );
    
    res.json({ 
      success: true, 
      announcementId: result.insertId,
      message: 'Announcement created successfully' 
    });
  } catch (error) {
    logger.error('Error creating announcement:', error);
    res.status(500).json({ error: 'Failed to create announcement' });
  }
});

/**
 * Get course announcements
 */
router.get('/courses/:courseId/announcements', lecturerAuthMiddleware, async (req, res) => {
  try {
    const { courseId } = req.params;
    
    const announcements = await db.queryPromise(
      `SELECT a.*, l.full_name as author_name
       FROM announcements a
       JOIN lecturers l ON a.created_by = l.id
       WHERE a.course_id = ? AND a.type = 'course'
       ORDER BY a.is_pinned DESC, a.created_at DESC`,
      [courseId]
    );
    
    res.json(announcements);
  } catch (error) {
    logger.error('Error fetching announcements:', error);
    res.status(500).json({ error: 'Failed to fetch announcements' });
  }
});

/**
 * Mark attendance for a batch
 */
router.post('/batches/:batchId/attendance', lecturerAuthMiddleware, async (req, res) => {
  try {
    const { batchId } = req.params;
    const { date, attendance_records } = req.body; // attendance_records is array of {student_id, status}
    const lecturerId = req.lecturer.lecturerId;
    
    // Verify lecturer has access to this batch
    const accessCheck = await db.queryPromise(
      'SELECT * FROM lecturer_batches WHERE lecturer_id = ? AND batch_id = ? AND status IN ("Assigned", "Active")',
      [lecturerId, batchId]
    );
    
    if (accessCheck.length === 0) {
      return res.status(403).json({ error: 'Access denied to this batch' });
    }
    
    // Insert or update attendance records
    for (const record of attendance_records) {
      await db.queryPromise(
        `INSERT INTO attendance (student_id, batch_id, date, status, marked_by)
         VALUES (?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE status = ?, marked_by = ?`,
        [record.student_id, batchId, date, record.status, lecturerId,
         record.status, lecturerId]
      );
    }
    
    res.json({ success: true, message: 'Attendance marked successfully' });
  } catch (error) {
    logger.error('Error marking attendance:', error);
    res.status(500).json({ error: 'Failed to mark attendance' });
  }
});

/**
 * Get attendance for a batch
 */
router.get('/batches/:batchId/attendance', lecturerAuthMiddleware, async (req, res) => {
  try {
    const { batchId } = req.params;
    const { date } = req.query;
    
    let query = `
      SELECT a.*, s.full_name as student_name, s.id_number
      FROM attendance a
      JOIN students s ON a.student_id = s.id
      WHERE a.batch_id = ?
    `;
    
    const params = [batchId];
    
    if (date) {
      query += ' AND a.date = ?';
      params.push(date);
    }
    
    query += ' ORDER BY a.date DESC, s.full_name';
    
    const attendance = await db.queryPromise(query, params);
    res.json(attendance);
  } catch (error) {
    logger.error('Error fetching attendance:', error);
    res.status(500).json({ error: 'Failed to fetch attendance' });
  }
});

/**
 * Get students in a batch
 */
router.get('/batches/:batchId/students', lecturerAuthMiddleware, async (req, res) => {
  try {
    const { batchId } = req.params;
    
    const students = await db.queryPromise(
      `SELECT s.*, sb.attendance_percentage, sb.status as enrollment_status
       FROM students s
       JOIN student_batches sb ON s.id = sb.student_id
       WHERE sb.batch_id = ?
       ORDER BY s.full_name`,
      [batchId]
    );
    
    res.json(students);
  } catch (error) {
    logger.error('Error fetching batch students:', error);
    res.status(500).json({ error: 'Failed to fetch students' });
  }
});

// Get batch details
router.get('/batches/:batchId', lecturerAuthMiddleware, async (req, res) => {
  try {
    const { batchId } = req.params;
    const lecturerId = req.lecturer.lecturerId;
    
    // Check if lecturer is assigned to this batch
    const assignmentCheck = await db.queryPromise(
      'SELECT * FROM lecturer_batches WHERE lecturer_id = ? AND batch_id = ?',
      [lecturerId, batchId]
    );
    
    if (assignmentCheck.length === 0) {
      return res.status(403).json({ message: 'Not assigned to this batch' });
    }
    
    // Get batch details with course info
    const batchQuery = `
      SELECT 
        b.*,
        c.name as courseName,
        c.id as courseId
      FROM batches b
      JOIN courses c ON b.course_id = c.id
      WHERE b.id = ?
    `;
    
    const batch = await db.queryPromise(batchQuery, [batchId]);
    res.json(batch[0]);
  } catch (error) {
    logger.error('Error fetching batch details:', error);
    res.status(500).json({ message: 'Failed to fetch batch details' });
  }
});

// Get students in a batch
router.get('/batches/:batchId/students', lecturerAuthMiddleware, async (req, res) => {
  try {
    const { batchId } = req.params;
    const lecturerId = req.lecturer.lecturerId;
    
    // Check if lecturer is assigned to this batch
    const assignmentCheck = await db.queryPromise(
      'SELECT * FROM lecturer_batches WHERE lecturer_id = ? AND batch_id = ?',
      [lecturerId, batchId]
    );
    
    if (assignmentCheck.length === 0) {
      return res.status(403).json({ message: 'Not assigned to this batch' });
    }
    
    // Get students in the batch
    const studentsQuery = `
      SELECT 
        s.id,
        s.full_name,
        s.email,
        s.id_number as student_id,
        sb.enrollment_date,
        sb.status
      FROM students s
      JOIN student_batches sb ON s.id = sb.student_id
      WHERE sb.batch_id = ? AND sb.status = 'Active'
      ORDER BY s.full_name
    `;
    
    const students = await db.queryPromise(studentsQuery, [batchId]);
    res.json(students);
  } catch (error) {
    logger.error('Error fetching batch students:', error);
    res.status(500).json({ message: 'Failed to fetch batch students' });
  }
});

module.exports = router; 