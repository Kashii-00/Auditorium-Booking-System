const express = require('express');
const router = express.Router();
const db = require('../db');
const logger = require('../logger');
const { lecturerAuthMiddleware } = require('./lecturerAuthRoutes');
const { studentAuthMiddleware } = require('./studentAuthRoutes');

/**
 * Get attendance for a batch (lecturer view)
 * GET /api/attendance/batch/:batchId
 */
router.get('/batch/:batchId', lecturerAuthMiddleware, async (req, res) => {
  try {
    const { batchId } = req.params;
    const { date, moduleId } = req.query;
    
    let query = `
      SELECT a.*, s.full_name as student_name, s.id_number as student_id_number,
             m.module_name, lu.id as marked_by_id, l.full_name as marked_by_name
      FROM attendance a
      JOIN students s ON a.student_id = s.id
      LEFT JOIN course_modules m ON a.module_id = m.id
      JOIN lecturer_users lu ON a.marked_by = lu.id
      JOIN lecturers l ON lu.lecturer_id = l.id
      WHERE a.batch_id = ?
    `;
    
    const params = [batchId];
    
    if (date) {
      query += ' AND a.attendance_date = ?';
      params.push(date);
    }
    
    if (moduleId) {
      query += ' AND a.module_id = ?';
      params.push(moduleId);
    }
    
    query += ' ORDER BY a.attendance_date DESC, s.full_name ASC';
    
    const attendance = await db.queryPromise(query, params);
    
    res.json(attendance);
  } catch (error) {
    logger.error('Error fetching attendance:', error);
    res.status(500).json({ error: 'Failed to fetch attendance' });
  }
});

/**
 * Get attendance summary for a batch
 * GET /api/attendance/batch/:batchId/summary
 */
router.get('/batch/:batchId/summary', lecturerAuthMiddleware, async (req, res) => {
  try {
    const { batchId } = req.params;
    
    const query = `
      SELECT 
        s.id as student_id,
        s.full_name as student_name,
        s.id_number as student_id_number,
        COUNT(CASE WHEN a.status = 'Present' THEN 1 END) as present_count,
        COUNT(CASE WHEN a.status = 'Absent' THEN 1 END) as absent_count,
        COUNT(CASE WHEN a.status = 'Late' THEN 1 END) as late_count,
        COUNT(CASE WHEN a.status = 'Excused' THEN 1 END) as excused_count,
        COUNT(*) as total_sessions,
        ROUND((COUNT(CASE WHEN a.status IN ('Present', 'Late') THEN 1 END) * 100.0 / COUNT(*)), 2) as attendance_percentage
      FROM students s
      JOIN student_batches sb ON s.id = sb.student_id
      LEFT JOIN attendance a ON s.id = a.student_id AND a.batch_id = sb.batch_id
      WHERE sb.batch_id = ?
      GROUP BY s.id, s.full_name, s.id_number
      ORDER BY s.full_name ASC
    `;
    
    const summary = await db.queryPromise(query, [batchId]);
    
    // Update attendance percentage in student_batches
    for (const student of summary) {
      await db.queryPromise(
        'UPDATE student_batches SET attendance_percentage = ? WHERE student_id = ? AND batch_id = ?',
        [student.attendance_percentage || 0, student.student_id, batchId]
      );
    }
    
    res.json(summary);
  } catch (error) {
    logger.error('Error fetching attendance summary:', error);
    res.status(500).json({ error: 'Failed to fetch attendance summary' });
  }
});

/**
 * Mark attendance for a batch (lecturer only)
 * POST /api/attendance/batch/:batchId/mark
 */
router.post('/batch/:batchId/mark', lecturerAuthMiddleware, async (req, res) => {
  const conn = await db.getConnectionPromise();
  try {
    await conn.beginTransactionPromise();
    
    const { batchId } = req.params;
    const { attendance_date, module_id, attendance_records } = req.body;
    
    if (!attendance_date || !attendance_records || !Array.isArray(attendance_records)) {
      await conn.rollbackPromise();
      return res.status(400).json({ error: 'Date and attendance records are required' });
    }
    
    // Delete existing attendance for this date/module to avoid duplicates
    const deleteQuery = `
      DELETE FROM attendance 
      WHERE batch_id = ? AND attendance_date = ? 
      ${module_id ? 'AND module_id = ?' : 'AND module_id IS NULL'}
    `;
    
    const deleteParams = [batchId, attendance_date];
    if (module_id) deleteParams.push(module_id);
    
    await conn.queryPromise(deleteQuery, deleteParams);
    
    // Insert new attendance records
    for (const record of attendance_records) {
      const insertQuery = `
        INSERT INTO attendance
        (batch_id, student_id, attendance_date, module_id, 
         check_in_time, check_out_time, status, remarks, marked_by)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;
      
      await conn.queryPromise(insertQuery, [
        batchId,
        record.student_id,
        attendance_date,
        module_id || null,
        record.check_in_time || null,
        record.check_out_time || null,
        record.status || 'Absent',
        record.remarks || null,
        req.lecturer.lecturerUserId
      ]);
    }
    
    await conn.commitPromise();
    
    res.json({ 
      success: true, 
      message: 'Attendance marked successfully',
      recordsCount: attendance_records.length
    });
    
  } catch (error) {
    await conn.rollbackPromise();
    logger.error('Error marking attendance:', error);
    res.status(500).json({ error: 'Failed to mark attendance' });
  } finally {
    conn.release();
  }
});

/**
 * Update individual attendance record (lecturer only)
 * PUT /api/attendance/:id
 */
router.put('/:id', lecturerAuthMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    const { status, check_in_time, check_out_time, remarks } = req.body;
    
    const updateQuery = `
      UPDATE attendance
      SET status = ?, check_in_time = ?, check_out_time = ?, 
          remarks = ?, updated_at = NOW()
      WHERE id = ?
    `;
    
    const result = await db.queryPromise(updateQuery, [
      status,
      check_in_time,
      check_out_time,
      remarks,
      id
    ]);
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Attendance record not found' });
    }
    
    res.json({ success: true, message: 'Attendance updated successfully' });
    
  } catch (error) {
    logger.error('Error updating attendance:', error);
    res.status(500).json({ error: 'Failed to update attendance' });
  }
});

/**
 * Get student's own attendance (student view)
 * GET /api/attendance/my-attendance
 */
router.get('/my-attendance', studentAuthMiddleware, async (req, res) => {
  try {
    const studentId = req.student.studentId;
    const { batchId, courseId } = req.query;
    
    let query = `
      SELECT a.*, b.batch_name, c.courseName, m.module_name,
             l.full_name as marked_by_name
      FROM attendance a
      JOIN batches b ON a.batch_id = b.id
      JOIN courses c ON b.course_id = c.id
      LEFT JOIN course_modules m ON a.module_id = m.id
      JOIN lecturer_users lu ON a.marked_by = lu.id
      JOIN lecturers l ON lu.lecturer_id = l.id
      WHERE a.student_id = ?
    `;
    
    const params = [studentId];
    
    if (batchId) {
      query += ' AND a.batch_id = ?';
      params.push(batchId);
    }
    
    if (courseId) {
      query += ' AND c.id = ?';
      params.push(courseId);
    }
    
    query += ' ORDER BY a.attendance_date DESC';
    
    const attendance = await db.queryPromise(query, params);
    
    // Calculate attendance summary
    const summary = {
      total_sessions: attendance.length,
      present_count: attendance.filter(a => a.status === 'Present').length,
      absent_count: attendance.filter(a => a.status === 'Absent').length,
      late_count: attendance.filter(a => a.status === 'Late').length,
      excused_count: attendance.filter(a => a.status === 'Excused').length,
      attendance_percentage: 0
    };
    
    if (summary.total_sessions > 0) {
      summary.attendance_percentage = Math.round(
        ((summary.present_count + summary.late_count) * 100) / summary.total_sessions
      );
    }
    
    res.json({
      attendance: attendance,
      summary: summary
    });
    
  } catch (error) {
    logger.error('Error fetching student attendance:', error);
    res.status(500).json({ error: 'Failed to fetch attendance' });
  }
});

/**
 * Get attendance report for a date range
 * GET /api/attendance/report
 */
router.get('/report', lecturerAuthMiddleware, async (req, res) => {
  try {
    const { batchId, startDate, endDate } = req.query;
    
    if (!batchId || !startDate || !endDate) {
      return res.status(400).json({ error: 'Batch ID, start date, and end date are required' });
    }
    
    const query = `
      SELECT 
        s.id as student_id,
        s.full_name as student_name,
        s.id_number as student_id_number,
        DATE(a.attendance_date) as date,
        a.status,
        a.check_in_time,
        a.check_out_time,
        m.module_name
      FROM students s
      JOIN student_batches sb ON s.id = sb.student_id
      LEFT JOIN attendance a ON s.id = a.student_id 
        AND a.batch_id = sb.batch_id 
        AND a.attendance_date BETWEEN ? AND ?
      LEFT JOIN course_modules m ON a.module_id = m.id
      WHERE sb.batch_id = ?
      ORDER BY s.full_name ASC, a.attendance_date ASC
    `;
    
    const report = await db.queryPromise(query, [startDate, endDate, batchId]);
    
    res.json(report);
    
  } catch (error) {
    logger.error('Error generating attendance report:', error);
    res.status(500).json({ error: 'Failed to generate report' });
  }
});

module.exports = router; 