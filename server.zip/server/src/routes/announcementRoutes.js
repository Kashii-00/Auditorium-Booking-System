const express = require('express');
const router = express.Router();
const db = require('../db');
const logger = require('../logger');
const { lecturerAuthMiddleware } = require('./lecturerAuthRoutes');

/**
 * Get announcements (for students and lecturers)
 * GET /api/announcements
 */
router.get('/', async (req, res) => {
  try {
    const { courseId, batchId, type } = req.query;
    const userType = req.lecturer ? 'lecturer' : 'student';
    
    let query = `
      SELECT a.*, lu.id as created_by_id, l.full_name as created_by_name,
             c.courseName, b.batch_name
      FROM announcements a
      JOIN lecturer_users lu ON a.created_by = lu.id
      JOIN lecturers l ON lu.lecturer_id = l.id
      LEFT JOIN courses c ON a.course_id = c.id
      LEFT JOIN batches b ON a.batch_id = b.id
      WHERE a.status = 'Published'
      AND (a.expiry_date IS NULL OR a.expiry_date > NOW())
    `;
    
    const params = [];
    
    if (courseId) {
      query += ' AND (a.course_id = ? OR a.announcement_type = "General")';
      params.push(courseId);
    }
    
    if (batchId) {
      query += ' AND (a.batch_id = ? OR a.batch_id IS NULL)';
      params.push(batchId);
    }
    
    if (type) {
      query += ' AND a.announcement_type = ?';
      params.push(type);
    }
    
    query += ' ORDER BY a.is_pinned DESC, a.priority DESC, a.publish_date DESC';
    
    const announcements = await db.queryPromise(query, params);
    
    // Parse attachments JSON
    announcements.forEach(announcement => {
      if (announcement.attachments) {
        try {
          announcement.attachments = JSON.parse(announcement.attachments);
        } catch (e) {
          announcement.attachments = null;
        }
      }
    });
    
    res.json(announcements);
  } catch (error) {
    logger.error('Error fetching announcements:', error);
    res.status(500).json({ error: 'Failed to fetch announcements' });
  }
});

/**
 * Create announcement (lecturer only)
 * POST /api/announcements
 */
router.post('/', lecturerAuthMiddleware, async (req, res) => {
  try {
    const {
      title,
      content,
      announcement_type = 'General',
      course_id,
      batch_id,
      priority = 'Normal',
      is_pinned = false,
      expiry_date,
      attachments
    } = req.body;
    
    if (!title || !content) {
      return res.status(400).json({ error: 'Title and content are required' });
    }
    
    const insertQuery = `
      INSERT INTO announcements
      (title, content, announcement_type, course_id, batch_id, 
       priority, created_by, is_pinned, expiry_date, attachments)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    
    const result = await db.queryPromise(insertQuery, [
      title,
      content,
      announcement_type,
      course_id || null,
      batch_id || null,
      priority,
      req.lecturer.lecturerUserId,
      is_pinned,
      expiry_date || null,
      attachments ? JSON.stringify(attachments) : null
    ]);
    
    res.status(201).json({
      success: true,
      announcementId: result.insertId,
      message: 'Announcement created successfully'
    });
    
  } catch (error) {
    logger.error('Error creating announcement:', error);
    res.status(500).json({ error: 'Failed to create announcement' });
  }
});

/**
 * Update announcement (lecturer only)
 * PUT /api/announcements/:id
 */
router.put('/:id', lecturerAuthMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    const {
      title,
      content,
      announcement_type,
      priority,
      is_pinned,
      expiry_date,
      status,
      attachments
    } = req.body;
    
    const updateQuery = `
      UPDATE announcements
      SET title = ?, content = ?, announcement_type = ?,
          priority = ?, is_pinned = ?, expiry_date = ?,
          status = ?, attachments = ?, updated_at = NOW()
      WHERE id = ? AND created_by = ?
    `;
    
    const result = await db.queryPromise(updateQuery, [
      title,
      content,
      announcement_type,
      priority,
      is_pinned,
      expiry_date,
      status,
      attachments ? JSON.stringify(attachments) : null,
      id,
      req.lecturer.lecturerUserId
    ]);
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Announcement not found or you do not have permission to edit it' });
    }
    
    res.json({ success: true, message: 'Announcement updated successfully' });
    
  } catch (error) {
    logger.error('Error updating announcement:', error);
    res.status(500).json({ error: 'Failed to update announcement' });
  }
});

/**
 * Delete announcement (lecturer only)
 * DELETE /api/announcements/:id
 */
router.delete('/:id', lecturerAuthMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    
    const deleteQuery = `
      DELETE FROM announcements
      WHERE id = ? AND created_by = ?
    `;
    
    const result = await db.queryPromise(deleteQuery, [
      id,
      req.lecturer.lecturerUserId
    ]);
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Announcement not found or you do not have permission to delete it' });
    }
    
    res.json({ success: true, message: 'Announcement deleted successfully' });
    
  } catch (error) {
    logger.error('Error deleting announcement:', error);
    res.status(500).json({ error: 'Failed to delete announcement' });
  }
});

/**
 * Mark announcement as read
 * POST /api/announcements/:id/read
 */
router.post('/:id/read', async (req, res) => {
  try {
    const { id } = req.params;
    
    // Increment views count
    await db.queryPromise(
      'UPDATE announcements SET views_count = views_count + 1 WHERE id = ?',
      [id]
    );
    
    res.json({ success: true });
    
  } catch (error) {
    logger.error('Error marking announcement as read:', error);
    res.status(500).json({ error: 'Failed to mark as read' });
  }
});

module.exports = router; 